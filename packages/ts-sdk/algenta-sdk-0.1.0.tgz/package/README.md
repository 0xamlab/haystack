# algenta-sdk

TypeScript and JavaScript SDK for Algenta public data, query, and simulation APIs.

## Install

```bash
npm install algenta-sdk
```

## Root Contract Exports

```ts
import { DEFAULT_BASE_URL, PRIMARY_DATA_QUERY_CONTRACT } from "algenta-sdk";

console.log(DEFAULT_BASE_URL);
console.log(PRIMARY_DATA_QUERY_CONTRACT.api.contract_endpoint);
console.log(PRIMARY_DATA_QUERY_CONTRACT.api.query_batch_endpoint);
console.log(PRIMARY_DATA_QUERY_CONTRACT.governed_filter_contract.operators.scalar);
```

## Direct Client Flow

```ts
import { AlgentaClient, type QueryFilterSpec } from "algenta-sdk";

const client = new AlgentaClient({
  apiKey: "de_live_...",
  baseUrl: "https://api.algenta.ai",
});

const datasets = await client.listDatasets({ search: "orders", compact: true });
const contract = await client.getContract();
const summary = await client.getDatasetSummary(datasets.datasets[0].dataset_id);
const completedOrders: QueryFilterSpec = {
  time_filter: "last_year",
  conditions: [{ dimension_hint: "status", op: "eq", value: "completed" }],
};

const query = await client.queryWithMetadata({
  dataset_id: summary.dataset_id,
  filter: completedOrders,
  metric: { hint: "gross_revenue" },
  aggregation: "sum",
});

const batch = await client.queryBatch({
  defaults: {
    dataset_id: summary.dataset_id,
    filter: completedOrders,
  },
  queries: [
    {
      key: "completed_orders",
      request: {
        metric: { hint: "order_count" },
        aggregation: "sum",
      },
    },
    {
      key: "monthly_completed_orders",
      request: {
        metric: { hint: "order_count" },
        aggregation: "sum",
        group_by: ["order_month"],
        limit: 12,
        order: "desc",
      },
    },
  ],
});

const report = await client.querySqlReport({
  sources: [{ dataset_id: summary.dataset_id, alias: "orders" }],
  sql: "SELECT order_month, gross_revenue FROM orders ORDER BY order_month DESC LIMIT 12",
  max_rows: 100,
});
```

`query()` remains available and unchanged when you only need the governed query body.

`client.getContract()` also handles older self-hosted nodes that still return
`404` for `/v1/meta/contract` by falling back to `/openapi.json` and reading
`x-primary-data-query-contract`.

The governed filter model is a **record-filter contract** over normalized rows,
not SQL. Use `QueryFilterSpec` / `QueryFilterCondition` for deterministic exact
slices that also stay valid for Redis and other non-SQL sources. The
machine-readable operator families and validation rules are published under
`PRIMARY_DATA_QUERY_CONTRACT.governed_filter_contract`.

## Public Methods

- `listDatasets({ search, status, sourceName, page, limit, compact })`
- `getContract()`
- `getDatasetSummary(datasetId)`
- `queryWithMetadata(request)`
- `queryBatch(request)`
- `querySqlReport(request)`
- `simulate(request)`

The package exports `QueryFilterSpec` and `QueryFilterCondition` from the root
type surface, so callers can build deterministic exact-query filters without
inventing private request shapes.

## Local Consumer Sync Checklist

If a local app still only exposes a pagination-only `listDatasets(...)` shape,
it is using a stale `algenta-sdk` build or a vendored copy that has not been
synced yet.

1. Rebuild the package from the repo root:

   ```bash
   pnpm --dir packages/ts-sdk build
   ```

2. Restart the consuming app or dev server after the build completes.
3. Verify the local package now exposes:
   - `listDatasets({ search, status, sourceName, page, limit, compact })`
   - `getContract()`
   - `getDatasetSummary(datasetId)`
   - `queryWithMetadata(request)`
   - `queryBatch(request)`
   - `querySqlReport(request)`

## Runtime and Local Libraries

```ts
import { Runtime, libraries } from "algenta-sdk";

const rt = new Runtime({
  mode: "self_hosted",
  apiKey: "de_live_...",
  baseUrl: "https://api.algenta.ai",
});

const catalog = await libraries({ mode: "local" });
```

`Runtime` uses the governed hosted or self-hosted data/query surface. `libraries()` remains the local/runtime-backed Mojo catalog.

## Docs

- [Algenta TypeScript docs](https://docs.algenta.ai/sdks/typescript)
- [Direct API client guide](https://docs.algenta.ai/direct-api-client)
